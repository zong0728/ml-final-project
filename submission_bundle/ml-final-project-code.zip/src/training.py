"""Seed control, append-only run logging, resume support, summary tables."""
from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import pandas as pd

from . import config


# ============================================================================
# Seeds
# ============================================================================

def set_seed(seed: int, torch_too: bool = False) -> None:
    """Set random seeds. Set torch_too=True ONLY for neural-net models —
    importing torch here can deadlock with LightGBM OpenMP on macOS.
    """
    random.seed(seed)
    np.random.seed(seed)
    if torch_too:
        try:
            import torch
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
        except ImportError:
            pass


# ============================================================================
# Append-only run log (fold-aware)
# ============================================================================

_LOG_COLS = [
    "timestamp", "model", "seed", "horizon", "fold",
    "val_rmse", "train_time_s", "config",
]


def _resolved_csv_path(csv_path: Path) -> Path:
    """Allow per-process CSV to avoid concurrent-write corruption from sbatch
    array jobs. If env var OUTAGE_RUNS_CSV is set, use that. Otherwise default."""
    import os
    override = os.environ.get("OUTAGE_RUNS_CSV")
    return Path(override) if override else csv_path


def log_run_fold(
    model_name: str,
    seed: int,
    horizon: int,
    fold: int,
    val_rmse: float,
    train_time_s: float,
    config_dict: dict | None = None,
    csv_path: Path = config.RUNS_CSV,
) -> None:
    """Append one (model, seed, horizon, fold) row."""
    csv_path = _resolved_csv_path(csv_path)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    row = {
        "timestamp": pd.Timestamp.now().isoformat(timespec="seconds"),
        "model": model_name,
        "seed": seed,
        "horizon": horizon,
        "fold": fold,
        "val_rmse": round(float(val_rmse), 4),
        "train_time_s": round(float(train_time_s), 2),
        "config": json.dumps(config_dict or {}, default=str),
    }
    df = pd.DataFrame([row], columns=_LOG_COLS)
    write_header = not csv_path.exists()
    df.to_csv(csv_path, mode="a", header=write_header, index=False)


# Back-compat: pre-fold rows (no `fold` col). Treated as fold=-1.
def log_run(
    model_name: str, seed: int, horizon: int,
    val_rmse: float, train_time_s: float,
    config_dict: dict | None = None,
    csv_path: Path = config.RUNS_CSV,
) -> None:
    log_run_fold(model_name, seed, horizon, fold=-1,
                 val_rmse=val_rmse, train_time_s=train_time_s,
                 config_dict=config_dict, csv_path=csv_path)


def load_runs(csv_path: Path = config.RUNS_CSV) -> pd.DataFrame:
    csv_path = _resolved_csv_path(csv_path)
    if not csv_path.exists():
        return pd.DataFrame(columns=_LOG_COLS)
    df = pd.read_csv(csv_path)
    if "fold" not in df.columns:
        df["fold"] = -1
    return df


def already_ran(model: str, seed: int, horizon: int, csv_path: Path = config.RUNS_CSV) -> bool:
    df = load_runs(csv_path)
    if df.empty:
        return False
    mask = ((df["model"] == model)
            & (df["seed"].astype(int) == int(seed))
            & (df["horizon"].astype(int) == int(horizon)))
    return bool(mask.any())


def already_ran_fold(model: str, seed: int, horizon: int, fold: int,
                     csv_path: Path = config.RUNS_CSV) -> bool:
    df = load_runs(csv_path)
    if df.empty:
        return False
    mask = ((df["model"] == model)
            & (df["seed"].astype(int) == int(seed))
            & (df["horizon"].astype(int) == int(horizon))
            & (df["fold"].astype(int) == int(fold)))
    return bool(mask.any())


# ============================================================================
# Summary
# ============================================================================

def summarize_runs(csv_path: Path = config.RUNS_CSV) -> pd.DataFrame:
    """Aggregate per (model, horizon) across folds and seeds.

    Reports BOTH mean and median across folds.

    Why median is the primary ranking signal here:
        Our 6 rolling-origin folds include exactly one fold that lands in
        the largest historical storm of the year (fold 1, peak 86k outages,
        RMSE 700-900 for every single model regardless of architecture).
        That one fold inflates mean RMSE by 5x relative to the typical fold.
        Mean RMSE therefore measures "luck on a single OOD extreme event"
        rather than "typical predictive quality". Median across folds gives
        the typical-day RMSE that is meaningful for model selection.

    Also returns:
        rmse_calm_mean: average RMSE excluding fold 1 (the storm fold)
        rmse_storm:     RMSE on fold 1 only (storm-period stress test)
    """
    df = load_runs(csv_path)
    if df.empty:
        return df
    # First average over seeds within each (model, horizon, fold)
    per_fold = (
        df.groupby(["model", "horizon", "fold"])["val_rmse"]
        .mean().reset_index()
    )

    # Drop legacy fold=-1 rows (single-window pre-CV runs) from aggregation
    per_fold_real = per_fold[per_fold["fold"] >= 0].copy()

    # Standard mean/median/std/min/max
    agg = (
        per_fold_real.groupby(["model", "horizon"])["val_rmse"]
        .agg(mean="mean", median="median", std="std", min="min", max="max", n="count")
        .reset_index()
    )

    # Calm-period mean (exclude fold 1, the big-storm fold)
    calm = per_fold_real[per_fold_real["fold"] != 1].groupby(
        ["model", "horizon"])["val_rmse"].mean().reset_index().rename(
        columns={"val_rmse": "calm_mean"})
    agg = agg.merge(calm, on=["model", "horizon"], how="left")

    # Storm fold RMSE (fold 1 only)
    storm = per_fold_real[per_fold_real["fold"] == 1].groupby(
        ["model", "horizon"])["val_rmse"].mean().reset_index().rename(
        columns={"val_rmse": "storm_rmse"})
    agg = agg.merge(storm, on=["model", "horizon"], how="left")

    agg["val_rmse_mean"]   = agg["mean"].round(4)
    agg["val_rmse_median"] = agg["median"].round(4)
    agg["val_rmse_std"]    = agg["std"].fillna(0.0).round(4)
    agg["val_rmse_min"]    = agg["min"].round(4)
    agg["val_rmse_max"]    = agg["max"].round(4)
    agg["calm_mean"]       = agg["calm_mean"].round(4)
    agg["storm_rmse"]      = agg["storm_rmse"].round(4)

    agg = agg[["model", "horizon",
                "val_rmse_median", "calm_mean", "storm_rmse",
                "val_rmse_mean", "val_rmse_std", "val_rmse_min", "val_rmse_max", "n"]]
    # Primary ranking: median (typical-day RMSE)
    return agg.sort_values(["horizon", "val_rmse_median"]).reset_index(drop=True)


def best_model_per_horizon(csv_path: Path = config.RUNS_CSV) -> dict[int, str]:
    """Return {horizon: best_model_name} based on mean val_rmse."""
    summary = summarize_runs(csv_path)
    if summary.empty:
        return {}
    best: dict[int, str] = {}
    for h in sorted(summary["horizon"].unique()):
        sub = summary[summary["horizon"] == h]
        best[int(h)] = str(sub.iloc[0]["model"])
    return best
